/**
 *  自定义控件书写模板
 */
    // 构造函数，变量名随意，与最后一句代码的KDApi.register的第二个参数一致即可
    function testbt (model) {
        this._setModel(model)
    }

    // 原型中封装生命周期函数，固定格式
    testbt.prototype = {
        _setModel: function(model) {
            this.model = model
        },
        init: function(props){
            // TO DO
            initFunc(this.model, props)
        },
        update: function(props){
            // TO DO
        },
        destoryed: function(){
            // TO DO
        }
    }

    var initFunc = function(model, props) {
        // KDApi.loadFile可以通过路径加载js或css文件，并且在html文件头生成script或者link标签，第一个参数是路径，第二个参数是model，第三个参数是加载完成后执行的回调函数
        KDApi.loadFile('./css/testbt.css', model, function() {
            // 通过路径去获取html字符串，第一个参数是路径，第二个参数是model，第三个参数是HTML模板中变量的值
            KDApi.getTemplateStringByFilePath('./html/testbt.html', model, {
                //text: ''
            }).then(function(result) {
                model.dom.innerHTML = result
                initEvent(model, props)
            })
        })
    }

    var initEvent = function(model, props){
	var btn = document.getElementById("mybt")
	btn.onclick = function() {
		alert("你好 mybt");
	}
    }

    // KDApi注册一个id号，这个id号要和控件方案的id号对应
    KDApi.register('clickbt', testbt)